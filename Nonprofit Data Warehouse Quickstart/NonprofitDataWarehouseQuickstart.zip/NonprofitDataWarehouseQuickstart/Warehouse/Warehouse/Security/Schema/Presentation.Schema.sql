﻿-- Copyright (c) Microsoft Corporation.
-- Licensed under the MIT License.

CREATE SCHEMA [Presentation]
    AUTHORIZATION [dbo];